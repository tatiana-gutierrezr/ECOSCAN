package com.example.ecoscan

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class ForgotPassActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password)
        }
}