package com.example.ecoscan

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.fragment.app.Fragment
import android.content.Intent
import android.util.Log

class HomeFragment : Fragment(R.layout.fragment_home) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val btnInfo = view.findViewById<Button>(R.id.btnInfo)
        val btnUbicacion = view.findViewById<Button>(R.id.btnUbicacion)
        val btnHistorial = view.findViewById<Button>(R.id.btnHistorial)

        // Redimensionar y asignar iconos
        btnInfo.setCompoundDrawablesWithIntrinsicBounds(resizeDrawable(R.drawable.informacion, 390, 270), null, null, null)
        btnUbicacion.setCompoundDrawablesWithIntrinsicBounds(resizeDrawable(R.drawable.pinlocacion, 263, 360), null, null, null)
        btnHistorial.setCompoundDrawablesWithIntrinsicBounds(resizeDrawable(R.drawable.historial, 210, 180), null, null, null)

        // Establecer el OnClickListener para btnUbicacion
        btnUbicacion.setOnClickListener {
            openMapsFragment()
        }
    }

    private fun openMapsFragment() {
        Log.d("HomeFragment", "Abriendo MapsFragment")

        // Instancia el fragmento de mapas
        val mapsFragment = MapsFragment()

        // Realiza la transacción de fragmentos
        parentFragmentManager.beginTransaction().apply {
            replace(R.id.fragment_container, mapsFragment) // Asegúrate de usar el ID correcto del contenedor
            addToBackStack(null) // Permite volver al fragmento anterior al presionar "Atrás"
            commit() // Aplica la transacción
        }
    }

    private fun resizeDrawable(drawableId: Int, width: Int, height: Int): BitmapDrawable {
        val bitmap = BitmapFactory.decodeResource(resources, drawableId)
        val resizedBitmap = Bitmap.createScaledBitmap(bitmap, width, height, true)
        return BitmapDrawable(resources, resizedBitmap)
    }
}