package com.example.ecoscan

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import android.content.Intent
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // Configuración inicial
        setup()

        // Manejo del botón de la flecha para volver a la pantalla principal
        val backArrow = findViewById<ImageButton>(R.id.backarrow)
        backArrow.setOnClickListener {
            // Volver a la pantalla principal
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
            finish() // Para evitar que el usuario pueda regresar a esta actividad con el botón atrás
        }

        // Botón olvidar contraseña
        val btnForgotPassword = findViewById<TextView>(R.id.forgotPassword)
        btnForgotPassword.setOnClickListener {
            val intent = Intent(this, ForgotPassActivity::class.java)
            startActivity(intent)
        }
    }

    private fun setup() {
        val loginButton = findViewById<Button>(R.id.btnIniciarSesion)
        val emailInput = findViewById<EditText>(R.id.emailInput)
        val passwordInput = findViewById<EditText>(R.id.passwordInput)

        loginButton.setOnClickListener {
            if (emailInput.text.isNotEmpty() && passwordInput.text.isNotEmpty()) {
                val email = emailInput.text.toString().trim()
                val password = passwordInput.text.toString().trim()

                // Intentar iniciar sesión con correo electrónico y contraseña
                FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener {
                        if (it.isSuccessful) {
                            val user = FirebaseAuth.getInstance().currentUser
                            if (user != null && user.isEmailVerified) {
                                // Si el correo está verificado, permitir el acceso
                                goToMain()
                            } else {
                                // Si no está verificado, mostrar alerta
                                showAlert("Verificación requerida", "Por favor, verifica tu correo electrónico antes de iniciar sesión.")
                            }
                        } else {
                            // Mostrar alerta si las credenciales son incorrectas
                            showAlert("Error", "Correo o contraseña incorrectos")
                        }
                    }
            } else {
                // Mostrar alerta si los campos están vacíos
                showAlert("Campos incompletos", "Por favor, completa todos los campos para continuar.")
            }
        }
    }

    // Método para mostrar el AlertDialog de forma consistente
    private fun showAlert(title: String, message: String) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle(title)
        builder.setMessage(message)
        builder.setPositiveButton("Aceptar") { dialog, _ -> dialog.dismiss() } // Cierra el diálogo al pulsar aceptar
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }

    private fun goToMain() {
        // Inicia la actividad principal y finaliza la actual
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish() // Evitar que el usuario regrese a la pantalla de login
    }
}