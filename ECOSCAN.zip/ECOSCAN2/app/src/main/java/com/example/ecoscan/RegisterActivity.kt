package com.example.ecoscan

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import android.content.Intent
import android.widget.Toast
import android.widget.ImageButton
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import android.util.Log

class RegisterActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        // Manejo del botón de la flecha para volver a la pantalla principal
        val backArrow = findViewById<ImageButton>(R.id.backarrow)
        backArrow.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
            finish() // Para evitar que el usuario pueda regresar a esta actividad con el botón atrás
        }

        // Configuración inicial
        setup()
    }

    private fun setup() {
        val registerButton = findViewById<Button>(R.id.btnCrearCuenta)
        val emailInput = findViewById<EditText>(R.id.emailInput)
        val passwordInput = findViewById<EditText>(R.id.passwordInput)
        val fullNameInput = findViewById<EditText>(R.id.fullnameInput)

        registerButton.setOnClickListener {
            // Verificar que los campos no estén vacíos
            if (emailInput.text.isNotEmpty() && passwordInput.text.isNotEmpty() && fullNameInput.text.isNotEmpty()) {
                val email = emailInput.text.toString().trim()
                val password = passwordInput.text.toString().trim()
                val fullName = fullNameInput.text.toString().trim()

                // Registrar el usuario en Firebase Authentication
                FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this) { task ->
                        if (task.isSuccessful) {
                            val user = FirebaseAuth.getInstance().currentUser
                            user?.let {
                                val userId = it.uid
                                val username = email.substringBefore("@") // Obtener el nombre de usuario

                                // Guardar el nombre en Firestore
                                saveUserToFirestore(userId, fullName, email, username)

                                // Enviar correo de verificación
                                it.sendEmailVerification().addOnCompleteListener { verifyTask ->
                                    if (verifyTask.isSuccessful) {
                                        // Mostrar mensaje con el nombre de usuario
                                        showAlert("Registro exitoso", "Te hemos enviado un correo para verificar tu cuenta. Tu nombre de usuario es '$username'. Por favor, revisa tu bandeja de entrada y sigue el enlace.")
                                        FirebaseAuth.getInstance().signOut() // Cerrar sesión hasta que verifique
                                    } else {
                                        showAlert("Error", "Hubo un problema al enviar el correo de verificación.")
                                    }
                                }
                            }
                        } else {
                            // Manejo de errores detallado
                            handleRegistrationErrors(task.exception, emailInput, passwordInput)
                        }
                    }
            } else {
                Toast.makeText(this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Guardar usuario en Firestore
    private fun saveUserToFirestore(userId: String, fullName: String, email: String, username: String) {
        val db = FirebaseFirestore.getInstance()

        val userMap = hashMapOf(
            "userId" to userId,
            "fullName" to fullName,
            "email" to email,
            "username" to username  // Guardar nombre de usuario
        )

        db.collection("users").document(userId).set(userMap)
            .addOnSuccessListener {
                Toast.makeText(this, "Usuario registrado exitosamente", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error al guardar los datos del usuario", Toast.LENGTH_SHORT).show()
            }
    }

    private fun handleRegistrationErrors(exception: Exception?, emailInput: EditText, passwordInput: EditText) {
        try {
            throw exception ?: return
        } catch (e: FirebaseAuthWeakPasswordException) {
            passwordInput.error = "Contraseña demasiado débil: ${e.message}"
            passwordInput.requestFocus()
        } catch (e: FirebaseAuthUserCollisionException) {
            emailInput.error = "Este correo ya está registrado: ${e.message}"
            emailInput.requestFocus()
        } catch (e: FirebaseAuthInvalidCredentialsException) {
            emailInput.error = "Correo no válido: ${e.message}"
            emailInput.requestFocus()
        } catch (e: Exception) {
            Log.e(RegisterActivity::class.java.name, "Error desconocido: ${e.message}")
            showAlert("Error", "Se ha producido un error en el registro.")
        }
    }

    // Método para mostrar el AlertDialog de forma consistente
    private fun showAlert(title: String, message: String) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle(title)
        builder.setMessage(message)
        builder.setPositiveButton("Aceptar") { dialog, _ -> dialog.dismiss() } // Cierra el diálogo al pulsar aceptar
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }
}